/**
 * Store the information of an edge.
 * In future versions, the weight will be added
 */
public class Edge {
    int to;

    public Edge(int to) {
        this.to = to;
    }
    
}