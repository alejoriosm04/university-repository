/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author htrefftz
 */
public class EdgeBellmanFord {
    int u;
    int v;
    int w;

    public EdgeBellmanFord(int u, int v, int w) {
        this.u = u;
        this.v = v;
        this.w = w;
    }

}
