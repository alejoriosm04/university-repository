#pragma once
#include <iostream>
#include <string>
#include "Data.h"

using namespace std;

class Dictionary {
    private:
        Data* data;
        string key;

    public:
        Dictionary* next;
        Dictionary(string key, Data* data, Dictionary* next);
        void add(string key, Data* data);
        Data* get(string key);
};