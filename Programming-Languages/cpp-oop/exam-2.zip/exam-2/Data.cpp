#include <iostream>
#include <string>
#include "Data.h"

using namespace std;

Data::Data(string marca, string modelo){
    this->marca = marca;
    this->modelo = modelo;
}

Data::Data(){
    this->marca = "Sin marca";
    this->modelo = "Sin modelo";
}

string Data::verDatos(){
    string valor = "Data: ";
    valor = valor + this->marca + " - (Modelo: " + this->modelo + ")";
    return valor;
}