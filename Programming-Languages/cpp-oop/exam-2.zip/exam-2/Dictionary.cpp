#include <iostream>
#include <string>
#include "Dictionary.h"

using namespace std;

Dictionary::Dictionary(Data* data, string key, Dictionary* next){
    this->data = data;
    this->key = key;
    this->next = next;
}

void add(string key, Data* data){

}

Data* get(string key){

}