#pragma once
#include <iostream>

using namespace std;

class Data {
    private:
        string marca;
        string modelo;

    public:
        Data(string marca, string modelo);
        Data();

};